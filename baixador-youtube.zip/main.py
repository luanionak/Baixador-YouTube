from fastapi import FastAPI, Query, Response, HTTPException
import yt_dlp
import os

app = FastAPI()

@app.get("/download")
def download_video(url: str = Query(...)):
    try:
        ydl_opts = {
            'format': 'best[ext=mp4]/best',
            'outtmpl': 'video.mp4',
            'noplaylist': True,
            'quiet': True,
            'no_warnings': True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        with open('video.mp4', 'rb') as f:
            content = f.read()
        os.remove('video.mp4')
        return Response(content=content, media_type="video/mp4")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))